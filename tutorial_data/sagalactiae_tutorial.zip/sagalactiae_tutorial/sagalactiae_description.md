# Streptococcus agalactiae tutorial schema

This schema was created with [chewBBACA v2.5.0](https://github.com/B-UMMI/chewBBACA).

## More information

Tutorial data is available in the [Chewie-NS_tutorial](https://github.com/B-UMMI/Chewie-NS_tutorial/tree/master/tutorial_data) GitHub repository.
